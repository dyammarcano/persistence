package persistence

import bolt "go.etcd.io/bbolt"

type (
	Persistence struct {
		*bolt.DB
	}
)

func NewPersistence(path string) (*Persistence, error) {
	db, err := bolt.Open(path, 0600, nil)
	if err != nil {
		return nil, err
	}

	return &Persistence{db}, nil
}

func (p *Persistence) Close() error {
	return p.DB.Close()
}

func (p *Persistence) Update(fn func(*bolt.Tx) error) error {
	return p.DB.Update(fn)
}

func (p *Persistence) View(fn func(*bolt.Tx) error) error {
	return p.DB.View(fn)
}

func (p *Persistence) Batch(fn func(*bolt.Tx) error) error {
	return p.DB.Batch(fn)
}
